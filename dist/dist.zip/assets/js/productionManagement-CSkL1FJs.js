import{a6 as o}from"./index-DN814Ow8.js";const p=t=>o.get(`/admin/production/product_output/list?${t}`),r=t=>o.post("/admin/production/product_output/save",t);export{p as a,r as p};
